/*! Zig Metamorphosis v3.0.0 © 2026 ZigFlames (zigflames.com). All rights reserved. Unauthorized copying, redistribution, resale, or removal of this notice is prohibited. License ZIGMETA3-A41F-9C27-E6B8 · sig:ZS-B7E2C91F04A65D38 */
'use strict';
const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
const IS_LITE = false;
const STORAGE_KEY = 'zigSettingsV3';
const MSG_SET = 'zig3-settings';
const MSG_STATUS = 'zig3-status';
const DEFAULTS = IS_LITE
  ? { enabled: false, mode: 'cycle', intensity: 55, speed: 40, adapt: 25, perf: 'medium', pace: 'normal' }
  : { enabled: false, mode: 'cycle', intensity: 55, speed: 40, adapt: 25, pace: 'normal' };
const $ = (id) => document.getElementById(id);
const els = { enabled: $('enabled'), mode: $('mode'), intensity: $('intensity'), speed: $('speed'), adapt: $('adapt') };
if (IS_LITE) els.perf = $('perf');
let settings = { ...DEFAULTS };

function render() {
  els.enabled.checked = !!settings.enabled;
  els.mode.value = settings.mode;
  if (IS_LITE && els.perf) els.perf.value = settings.perf;
  els.intensity.value = settings.intensity;
  els.speed.value = settings.speed;
  $('intensityVal').textContent = settings.intensity + '%';
  $('speedVal').textContent = settings.speed + '%';
  els.adapt.value = settings.adapt;
  $('adaptVal').textContent = settings.adapt + 's';
  $('adaptSection').hidden = settings.mode !== 'brain';
  for (const b of document.querySelectorAll('#pace button')) b.setAttribute('aria-checked', String(b.dataset.pace === settings.pace));
  $('paceVal').textContent = ({ slow: '0.5×', normal: '1×', fast: '2×', turbo: '3.5×' })[settings.pace] || '1×';
  $('paceHint').hidden = settings.mode !== 'brain';
}

async function activeTab() {
  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function push() {
  api.storage.local.set({ [STORAGE_KEY]: settings });
  try {
    const tab = await activeTab();
    if (tab && tab.id != null) {
      api.tabs.sendMessage(tab.id, { type: MSG_SET, settings }).catch(() => {});
    }
  } catch (e) { /* tab may not accept messages */ }
  setTimeout(refreshStatus, 350);
}

async function refreshStatus() {
  const status = $('status');
  try {
    const tab = await activeTab();
    if (!tab || tab.id == null || !/^(https?|file):/.test(tab.url || '')) {
      status.textContent = 'Open a page with a video to use effects.';
      return;
    }
    const res = await api.tabs.sendMessage(tab.id, { type: MSG_STATUS });
    if (!res) { status.textContent = 'Reload the page to activate.'; return; }
    if (!res.videos) status.textContent = 'No video found on this page yet.';
    else if (!settings.enabled) status.textContent = `${res.videos} video${res.videos > 1 ? 's' : ''} found — effect off`;
    else if (IS_LITE) {
      status.textContent = (res.gl || res.fallback ? 'Morphing the main video' : 'Waiting for a playing video') +
        (res.fallback ? ' (simplified mode: site blocks full effects)' : '');
    } else {
      status.textContent = `Morphing ${res.videos} video${res.videos > 1 ? 's' : ''}` +
        (res.fallback ? ' (simplified mode: site blocks full effects)' : '');
    }
  } catch (e) {
    status.textContent = 'Reload the page to activate.';
  }
}

els.enabled.addEventListener('change', () => { settings.enabled = els.enabled.checked; render(); push(); });
els.mode.addEventListener('change', () => { settings.mode = els.mode.value; render(); push(); });
if (IS_LITE && els.perf) els.perf.addEventListener('change', () => { settings.perf = els.perf.value; push(); });
$('pace').addEventListener('click', (e) => { const b = e.target.closest('button[data-pace]'); if (!b) return; settings.pace = b.dataset.pace; render(); push(); });
for (const k of ['intensity', 'speed', 'adapt']) {
  els[k].addEventListener('input', () => { settings[k] = Number(els[k].value); render(); push(); });
}

api.storage.local.get(STORAGE_KEY).then((data) => {
  settings = { ...DEFAULTS, ...((data && data[STORAGE_KEY]) || {}) };
  render();
  refreshStatus();
});
