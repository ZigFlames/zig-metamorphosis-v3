/*! Zig Metamorphosis v3.0.0 © 2026 ZigFlames (zigflames.com). All rights reserved. Unauthorized copying, redistribution, resale, or removal of this notice is prohibited. License ZIGMETA3-A41F-9C27-E6B8 · sig:ZS-B7E2C91F04A65D38 */
/* Zig Metamorphosis v3.0.0 content script. Profile: full.
   Draws live morph effects over HTML5 video with WebGL, or a CSS/SVG filter
   when a site blocks reading the video pixels. Nothing is uploaded. */
(() => {
  'use strict';
  const ZIG_OWNER = 'Zig Metamorphosis v3.0.0 © 2026 ZigFlames (zigflames.com). All rights reserved. Unauthorized copying, redistribution, resale, or removal of this notice is prohibited. License ZIGMETA3-A41F-9C27-E6B8 · sig:ZS-B7E2C91F04A65D38';
  const PROFILE = 'full'; // "full" or "lite"
  const IS_LITE = PROFILE === 'lite';
  const api = (typeof browser !== 'undefined' && browser.runtime) ? browser : chrome;
  const GUARD = IS_LITE ? '__zigMetaLiteV3' : '__zigMetaV3';
  if (window[GUARD]) return;
  window[GUARD] = true;

  const STORAGE_KEY = 'zigSettingsV3';
  const MSG_SET = 'zig3-settings';
  const MSG_STATUS = 'zig3-status';
  const QUERY_EVT = 'zig-metamorphosis-v3-query';
  const DATA_ATTR = 'data-zig-metamorphosis-v3';
  const FILTER_ID = 'zigmeta3-filter';
  const TURB_ID = 'zigmeta3-turb';
  const DISP_ID = 'zigmeta3-disp';
  const HUE_ID = 'zigmeta3-hue';
  const CANVAS_CLASS = 'zig-metamorphosis-v3-canvas';

  const DEFAULTS = IS_LITE
    ? { enabled: false, mode: 'cycle', intensity: 55, speed: 40, adapt: 25, perf: 'medium', pace: 'normal' }
    : { enabled: false, mode: 'cycle', intensity: 55, speed: 40, adapt: 25, pace: 'normal' };

  const MODES = {
    liquid: 0, dissolve: 1, refraction: 2, chroma: 3, cycle: 4, brain: 5,
    ripple: 6, kaleido: 7, smoke: 8, mirror: 9, shatter: 10, breathe: 11, vision: 12, thick: 13
  };
  const CYCLE = [0, 6, 1, 8, 2, 10, 3, 7, 11, 9];
  const PACE = { slow: 0.5, normal: 1, fast: 2, turbo: 3.5 };
  const LIGHT_CAP = 3, BRAIN_MAX_HZ = 0.9;
  const MIN_W = 80, MIN_H = 60;
  const MAX_BUFFER = IS_LITE ? 960 : 1600;
  const PERF = {
    low:    { fps: 15, scale: 0.5 },
    medium: { fps: 24, scale: 0.6 },
    high:   { fps: 30, scale: 0.85 }
  };
  const BRAIN_FPS = 15, BRAIN_SCALE = 0.75;

  const VERT = `/* Zig Metamorphosis v3.0.0 — vertex shader (full-screen triangle pair) */
attribute vec2 a_pos;
varying vec2 v_uv;
void main() { v_uv = a_pos * 0.5 + 0.5; gl_Position = vec4(a_pos, 0.0, 1.0); }
`;
  const FRAG = `/* Zig Metamorphosis v3.0.0 — full-quality fragment shader */
precision highp float;
    varying vec2 v_uv;
    uniform sampler2D u_tex;
    uniform float u_time;      // seconds, already scaled by speed
    uniform float u_int;       // 0..1 intensity
    uniform vec2  u_res;       // canvas px
    uniform vec4  u_crop;      // uv scale.xy, offset.zw (object-fit: cover)
    uniform float u_modeA;
    uniform float u_modeB;
    uniform float u_mix;
    uniform float u_brain;     // 1 = Brain Morph overlay (pattern only, transparent elsewhere)
    uniform float u_bType;     // 0 rotating spiral, 1 expanding flow, 2 peripheral drift
    uniform float u_bAlpha;    // envelope 0..1 (adapt, then ~2s fade)
    uniform float u_bPhase;    // pattern phase in cycles (per-pixel temporal freq <= ~0.9 Hz)
    uniform float u_bSpin;     // slow whole-pattern rotation (radians)
    uniform vec4 u_vis; uniform float u_vh, u_th;  // Zig Vision round state
    uniform float u_lt, u_gl;  // light clock (capped, for brightness changes) + glow gain (fades sparkle at high speed)

    float hash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
    float noise(vec2 p) {
      vec2 i = floor(p), f = fract(p);
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
                 mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
    }
    float fbm(vec2 p) {
      float v = 0.0, a = 0.5;
      mat2 r = mat2(0.8, -0.6, 0.6, 0.8);
      for (int i = 0; i < 5; i++) { v += a * noise(p); p = r * p * 2.02 + 3.1; a *= 0.5; }
      return v;
    }
    vec2 curl(vec2 p) {
      float e = 0.02;
      float n1 = fbm(p + vec2(0.0, e)), n2 = fbm(p - vec2(0.0, e));
      float n3 = fbm(p + vec2(e, 0.0)), n4 = fbm(p - vec2(e, 0.0));
      return vec2(n1 - n2, -(n3 - n4)) / (2.0 * e);
    }
    vec3 tex(vec2 uv) {
      uv = clamp(uv, 0.001, 0.999);
      return texture2D(u_tex, uv * u_crop.xy + u_crop.zw).rgb;
    }
    vec3 hueShift(vec3 c, float a) {
      const vec3 k = vec3(0.57735);
      float ca = cos(a);
      return c * ca + cross(k, c) * sin(a) + k * dot(k, c) * (1.0 - ca);
    }

    // 0: Liquid Melt — viscous curl-noise flow with gentle gravity drip
    vec3 liquid(vec2 uv, float t, float k) {
      vec2 p = uv * vec2(u_res.x / u_res.y, 1.0) * 2.2;
      vec2 flow = curl(p * 0.9 + vec2(t * 0.15, -t * 0.22));
      vec2 flow2 = curl(p * 1.7 - vec2(t * 0.1, t * 0.05) + flow * 0.3);
      vec2 d = (flow * 0.018 + flow2 * 0.008) * k;
      float drip = fbm(vec2(uv.x * 7.0, t * 0.3)) ;
      d.y += pow(drip, 2.0) * 0.06 * k * smoothstep(0.0, 1.0, 1.0 - uv.y);
      vec3 c = tex(uv + d);
      float sheen = smoothstep(0.55, 1.0, fbm(p * 1.3 + flow * 0.5 + t * 0.1));
      return c + sheen * 0.12 * k * u_gl;
    }

    // 1: Dissolve & Reform — noise threshold breathes in/out, particles scatter, edges glow
    vec3 dissolve(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 p = uv * vec2(aspect, 1.0);
      float n = fbm(p * 4.0 + vec2(0.0, t * 0.12));
      float cycle = 0.5 - 0.5 * cos(u_lt * 0.6);              // 0 -> 1 -> 0, continuous
      float th = cycle * (0.25 + 0.6 * k);                  // how much has broken down
      float edgeW = 0.03 + 0.05 * k;
      float solid = smoothstep(th - edgeW, th + edgeW, n);  // 1 = intact
      // particle field: cells that drift outward and upward
      float cells = mix(140.0, 60.0, k);
      vec2 cell = floor(uv * vec2(cells * aspect, cells)) ;
      float h = hash(cell);
      vec2 drift = (vec2(hash(cell + 7.1), hash(cell + 3.7)) - 0.5) * 0.12 * k * (1.0 - solid);
      drift.y += 0.05 * k * (1.0 - solid) * h;
      vec2 cuv = (cell + 0.5) / vec2(cells * aspect, cells);
      vec3 particle = tex(cuv - drift);
      vec2 f = fract(uv * vec2(cells * aspect, cells)) - 0.5;
      float dotMask = smoothstep(0.5, 0.15, length(f)) * step(1.0 - (1.0 - solid) * 0.9, h + 0.35);
      vec3 base = tex(uv);
      vec3 broken = particle * dotMask * 1.15 + base * 0.12;
      vec3 c = mix(broken, base, solid);
      float edge = 1.0 - smoothstep(0.0, edgeW * 1.5, abs(n - th));
      vec3 glow = mix(vec3(1.0, 0.35, 0.9), vec3(0.3, 0.9, 1.0), n);
      c += glow * edge * (0.25 + 0.9 * k) * step(0.02, th);
      return c;
    }

    // 2: Refraction — light bending through a shifting density field, with dispersion
    vec3 refraction(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 p = uv * vec2(aspect, 1.0);
      float e = 0.01;
      vec2 q = p * 2.0 + vec2(t * 0.07, t * 0.05);
      float d0 = fbm(q);
      vec2 grad = vec2(fbm(q + vec2(e, 0.0)) - d0, fbm(q + vec2(0.0, e)) - d0) / e;
      // two wandering lenses
      vec2 c1 = vec2(0.5 * aspect + 0.3 * aspect * sin(t * 0.21), 0.5 + 0.25 * cos(t * 0.17));
      vec2 c2 = vec2(0.5 * aspect + 0.35 * aspect * cos(t * 0.13 + 1.0), 0.5 + 0.3 * sin(t * 0.19 + 2.0));
      vec2 lens = vec2(0.0);
      for (int i = 0; i < 2; i++) {
        vec2 c = i == 0 ? c1 : c2;
        vec2 dv = p - c; float r = length(dv);
        lens += normalize(dv + 1e-5) * sin(r * 26.0 - t * 2.2) * exp(-r * 3.2) * 0.5;
      }
      vec2 off = (grad * 0.012 + lens * 0.018) * k;
      float disp = 0.35 * k;
      vec3 c;
      c.r = tex(uv + off * (1.0 + disp)).r;
      c.g = tex(uv + off).g;
      c.b = tex(uv + off * (1.0 - disp)).b;
      float caustic = pow(clamp(1.0 - length(grad) * 0.25, 0.0, 1.0), 6.0);
      c += (caustic * 0.10 * k + smoothstep(0.3, 1.0, length(lens)) * 0.08 * k) * u_gl;
      return c;
    }

    // 3: Chroma Morph — drifting RGB separation and slow hue migration
    vec3 chroma(vec2 uv, float t, float k) {
      float n = fbm(uv * 2.5 + t * 0.08);
      float ang = t * 0.35 + n * 3.0;
      vec2 dir = vec2(cos(ang), sin(ang));
      float amt = (0.004 + 0.016 * k) * (0.6 + 0.8 * n);
      vec2 wob = (vec2(fbm(uv * 3.0 + t * 0.2), fbm(uv * 3.0 - t * 0.2)) - 0.5) * 0.01 * k;
      vec3 c;
      c.r = tex(uv + dir * amt + wob).r;
      c.g = tex(uv + wob * 0.5).g;
      c.b = tex(uv - dir * amt + wob).b;
      float hue = (sin(t * 0.25) * 0.6 + (n - 0.5) * 2.0) * k * 1.6;
      vec3 shifted = hueShift(c, hue);
      return mix(c, shifted, 0.35 + 0.65 * k);
    }

    // ---- v2 morphs: all cheap (mediump-safe, <=9 noise/hash lookups, 1-3 texture reads), continuous, no hard swaps.
    // 6: Ripple Pool: rings spread from three slowly wandering drops, like a still pool being touched
    vec3 ripple(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 p = uv * vec2(aspect, 1.0), g = vec2(0.0);
      for (int i = 0; i < 3; i++) {
        float fi = float(i);
        vec2 c = vec2(aspect * (0.5 + 0.32 * sin(t * (0.11 + 0.04 * fi) + fi * 2.1)), 0.5 + 0.3 * cos(t * (0.09 + 0.03 * fi) + fi * 1.3));
        vec2 d = p - c;
        float r = length(d) + 0.001;
        g += d / r * sin(r * 34.0 - t * 2.4 + fi * 2.0) * exp(-r * 2.6);
      }
      vec3 c = tex(uv + g * 0.010 * k);
      return c + max(0.0, dot(g, vec2(0.6, 0.8))) * 0.06 * k * u_gl;
    }
    // 7: Kaleido Bloom: a soft six-petal mirror fold opens out from the centre, then closes back to the real picture
    vec3 kaleido(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
      float r = length(p), a = atan(p.y, p.x) + t * 0.05;
      float fa = abs(mod(a, 1.0471976) - 0.5235988);
      vec2 q = vec2(cos(fa), sin(fa)) * r * (1.0 + 0.04 * k * sin(t * 0.4 + r * 6.0));
      float bloom = (0.5 - 0.5 * cos(u_lt * 0.35)) * k;
      float w = clamp(bloom * smoothstep(0.05, 0.45, r) * (0.75 + 0.5 * noise(p * 3.0 + t * 0.1)), 0.0, 0.7);
      return mix(tex(uv), tex(q / vec2(aspect, 1.0) + 0.5), w);
    }
    // 8: Smoke Drift: the picture rises and curls like smoke (curl-noise flow) with soft haze in the wisps
    vec3 smoke(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 p = uv * vec2(aspect, 1.0) * 3.0 - vec2(0.0, t * 0.25);
      float n0 = noise(p), nx = noise(p + vec2(0.08, 0.0)), ny = noise(p + vec2(0.0, 0.08));
      vec2 cu = vec2(ny - n0, n0 - nx) * 12.5;
      float n2 = noise(p * 2.1 + cu * 0.4 + 5.0);
      vec3 c = tex(uv + (cu * 0.012 - vec2(0.0, 0.02 * n2)) * k);
      float wisp = smoothstep(0.45, 0.9, n2) * k * u_gl;
      return mix(c, mix(vec3(dot(c, vec3(0.333))), vec3(0.86, 0.86, 0.9), 0.35), wisp * 0.35);
    }
    // 9: Mirror Twin: a mirrored twin of the picture fuses in and out along a softly swaying axis
    vec3 mirror(vec2 uv, float t, float k) {
      float axis = 0.5 + 0.06 * sin(t * 0.13);
      vec2 m = vec2(2.0 * axis - uv.x, uv.y) + (vec2(noise(uv * 3.0 + t * 0.1), noise(uv * 3.0 - t * 0.1 + 4.0)) - 0.5) * 0.02 * k;
      float w = clamp(k * (0.3 + 0.25 * sin(u_lt * 0.3)) * (0.7 + 0.6 * noise(uv * 2.0 + t * 0.05)), 0.0, 0.6);
      return mix(tex(uv), tex(m), w);
    }
    // 10: Glass Shatter Flow: slow crystalline facets, each bending the light a little differently
    vec3 shatter(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 p = uv * vec2(aspect, 1.0) * 5.0, ip = floor(p), fp = fract(p), id = ip;
      float d1 = 8.0, d2 = 8.0;
      for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
        vec2 g = vec2(float(i), float(j));
        float h = hash(ip + g);
        float d = length(g + 0.5 + 0.38 * sin(t * 0.25 + 6.2831 * vec2(h, fract(h * 7.3))) - fp);
        if (d < d1) { d2 = d1; d1 = d; id = ip + g; } else if (d < d2) { d2 = d; }
      }
      float h = hash(id), ang = 6.2831 * h + t * 0.15;
      vec2 off = vec2(cos(ang), sin(ang)) * (0.006 + 0.014 * h) * k;
      float dp = 0.3 * k;
      vec3 c = vec3(tex(uv + off * (1.0 + dp)).r, tex(uv + off).g, tex(uv + off * (1.0 - dp)).b);
      return c + (1.0 - smoothstep(0.0, 0.06, d2 - d1)) * 0.10 * k * u_gl;
    }
    // 11: Pulse Breathe: the frame gently inhales and exhales (centre-weighted zoom with a soft twist)
    vec3 breathe(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
      float br = sin(u_lt * 0.9), fall = exp(-length(p) * 2.2);
      float sw = br * 0.12 * k * fall + (noise(p * 2.0 + t * 0.1) - 0.5) * 0.06 * k;
      float cs = cos(sw), sn = sin(sw);
      vec2 q = vec2(cs * p.x - sn * p.y, sn * p.x + cs * p.y) * (1.0 - br * 0.06 * k * fall);
      return tex(q / vec2(aspect, 1.0) + 0.5);
    }

    // 12: Zig Vision (perception boost): unsharp mask + vibrance, soft vignette focus pull, slow low-contrast peripheral
    // drift texture at the edges, and now and then a soft complementary-tint primer that fades so true colours look richer.
    // All round parameters (u_vis = primer, enhance, vignette, edge drift; u_vh = primer hue) ease over seconds in JS.
    vec3 vision(vec2 uv, float t, float k) {
      float aspect = u_res.x / u_res.y;
      vec2 px = 1.5 / u_res;
      vec3 c = tex(uv);
      vec3 bl = (tex(uv + vec2(px.x, 0.0)) + tex(uv - vec2(px.x, 0.0)) + tex(uv + vec2(0.0, px.y)) + tex(uv - vec2(0.0, px.y))) * 0.25;
      c += (c - bl) * (0.6 + 1.2 * u_vis.y) * k;
      float l = dot(c, vec3(0.299, 0.587, 0.114));
      float sat = max(max(c.r, c.g), c.b) - min(min(c.r, c.g), c.b);
      c = mix(vec3(l), c, 1.0 + (0.12 + 0.25 * u_vis.y) * k * (1.0 - sat));
      vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
      float r = length(p);
      c *= 1.0 - u_vis.z * k * smoothstep(0.35, 0.95, r) * 0.45;
      float saw = fract(atan(p.y, p.x) * 3.8197 + r * 6.0 - t * 0.05);
      c += (saw - 0.5) * 0.06 * smoothstep(0.45, 0.85, r) * u_vis.w * k;
      c = mix(c, mix(vec3(l), hueShift(vec3(0.62, 0.5, 0.42), u_vh), 0.5), u_vis.x * 0.35);
      return c;
    }

    // 13: Thick: smooth, organic horizontal widening of the lower-middle of the frame (roughly 45-80% down), strongest at the
    // centre and fading out toward the sides and above/below (waist-preserving falloff), slowly breathing; plus a warm skin
    // glow (warm tint, soft smoothing, highlight bloom, light saturation). u_th = amount (eased in over 3 s in JS).
    vec3 thick(vec2 uv, float t, float k) {
      float amt = u_th * (0.85 + 0.15 * sin(t * 0.5));
      float band = exp(-pow((uv.y - 0.375) / 0.16, 2.0));
      float dx = uv.x - 0.5;
      float s = 1.0 + amt * band * exp(-pow(dx / 0.32, 2.0));
      vec2 q = vec2(0.5 + dx / s, uv.y);
      vec3 c = tex(q), w = vec3(1.06, 1.0, 0.92);
      vec3 soft = (tex(q + vec2(0.004, 0.0)) + tex(q - vec2(0.004, 0.0)) + tex(q + vec2(0.0, 0.004)) + tex(q - vec2(0.0, 0.004))) * 0.25;
      float l = dot(c, vec3(0.299, 0.587, 0.114));
      c = mix(c, soft, 0.25 * k) * w + smoothstep(0.55, 1.0, l) * 0.05 * k;
      return mix(vec3(dot(c, vec3(0.299, 0.587, 0.114))), c, 1.0 + 0.12 * k);
    }

    vec3 effect(float m, vec2 uv, float t, float k) {
      if (m < 0.5) return liquid(uv, t, k);
      if (m < 1.5) return dissolve(uv, t, k);
      if (m < 2.5) return refraction(uv, t, k);
      if (m < 3.5) return chroma(uv, t, k);
      if (m < 6.5) return ripple(uv, t, k);
      if (m < 7.5) return kaleido(uv, t, k);
      if (m < 8.5) return smoke(uv, t, k);
      if (m < 9.5) return mirror(uv, t, k);
      if (m < 10.5) return shatter(uv, t, k);
      if (m < 11.5) return breathe(uv, t, k);
      if (m < 12.5) return vision(uv, t, k);
      return thick(uv, t, k);
    }

    // Brain Morph: motion-aftereffect adaptor. Smooth sinusoidal luminance (no hard edges),
    // slow drift; temporal frequency at any pixel is u_bPhase rate (capped < 1 Hz in JS).
    vec4 brain(vec2 uv) {
      float aspect = u_res.x / u_res.y;
      vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
      float r = length(p) + 1e-4;
      float th = atan(p.y, p.x);
      float k = u_int;
      float lum; float a;
      if (u_bType < 0.5) {
        // logarithmic spiral, 4 arms, rotating inward
        float ph = 4.0 * (th + u_bSpin) + 9.0 * log(r) - 6.2831853 * u_bPhase;
        lum = 0.5 + 0.5 * sin(ph);
        a = smoothstep(0.02, 0.12, r);
      } else if (u_bType < 1.5) {
        // expanding radial flow rings with a soft organic wobble
        float wob = 0.6 * sin(3.0 * th + u_bSpin * 2.0) * 0.15;
        float ph = 10.0 * log(r) + wob - 6.2831853 * u_bPhase;
        lum = 0.5 + 0.5 * sin(ph);
        a = smoothstep(0.02, 0.12, r);
      } else {
        // peripheral drift: asymmetric (sawtooth) luminance gradients in ring segments; static,
        // the illusory drift appears in peripheral vision. Very slow spin only.
        float seg = (th + u_bSpin * 0.2) / 6.2831853 * 24.0;
        float ring = floor(r * 9.0);
        float saw = fract(seg + mod(ring, 2.0) * 0.5);
        float ramp = saw < 0.8 ? saw / 0.8 : (1.0 - saw) / 0.2; // slow rise, quicker fall
        lum = mix(0.15, 0.85, ramp);
        a = smoothstep(0.12, 0.35, r) * 0.8;
      }
      // keep subject recognizable: translucent, with a calm centre
      float alpha = u_bAlpha * a * (0.18 + 0.47 * k);
      vec3 col = mix(vec3(0.05, 0.03, 0.10), vec3(0.95, 0.92, 1.0), lum);
      // tiny steady fixation point at the centre helps adaptation (never blinks)
      float dotA = (1.0 - smoothstep(0.004, 0.007, r)) * u_bAlpha * 0.9;
      col = mix(col, vec3(1.0, 0.3, 0.3), dotA);
      alpha = max(alpha, dotA);
      return vec4(col * alpha, alpha); // premultiplied
    }

    void main() {
      if (u_brain > 0.5) { gl_FragColor = brain(v_uv); return; }
      vec2 uv = v_uv;
      float k = u_int;
      vec3 a = effect(u_modeA, uv, u_time, k);
      vec3 col = a;
      if (u_mix > 0.001) {
        vec3 b = effect(u_modeB, uv, u_time, k);
        // organic crossfade: a noise front sweeps between stages instead of a flat fade
        float front = fbm(uv * 3.0 + u_time * 0.1);
        float w = smoothstep(front - 0.25, front + 0.25, u_mix * 1.5 - 0.25);
        col = mix(a, b, w);
      }
      gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
    }
`;

  let settings = { ...DEFAULTS };
  const stats = { draws: 0, uploads: 0 };
  let brainHz = 0;

  // Zig Vision: 30-45s rounds on real time, every change eases over >= 2s.
  let vRound = null;
  function visionState() {
    const now = performance.now() / 1000, R = Math.random;
    const ease = (u) => { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); };
    if (!vRound || now >= vRound.end || now < vRound.start) {
      const from = vRound ? vRound.cur.slice() : [0, 0.6, 0.6, 0.6];
      vRound = {
        start: now, end: now + 30 + 15 * R(), from,
        to: [0, 0.4 + 0.6 * R(), 0.3 + 0.7 * R(), 0.3 + 0.7 * R()],
        hue: 6.2832 * R(), prime: 0.5 + 0.5 * R(), cur: from
      };
    }
    const x = now - vRound.start, m = ease(x / 3);
    const cur = vRound.from.map((a, i) => a + (vRound.to[i] - a) * m);
    cur[0] = vRound.prime * (x < 2 ? ease(x / 2) : 1 - ease((x - 5) / 3));
    vRound.cur = cur;
    return [cur[0], cur[1], cur[2], cur[3], vRound.hue];
  }

  let thickSince = 0;
  function thickAmt(st) {
    if (!st || (st.a !== 13 && st.b !== 13)) { thickSince = 0; return 0; }
    const now = performance.now();
    if (!thickSince) thickSince = now;
    const u = Math.min(1, (now - thickSince) / 3000);
    return (0.08 + 0.10 * intensity()) * u * u * (3 - 2 * u);
  }
  function thickCss(k) {
    return ` sepia(${(0.18 * k).toFixed(3)}) saturate(${(1 + 0.15 * k).toFixed(3)}) brightness(1.03)`;
  }
  function visionCss(k) {
    const v = visionState();
    return ` contrast(${(1 + 0.12 * k * v[1]).toFixed(3)}) saturate(${(1 + 0.35 * k * v[1]).toFixed(3)}) sepia(${(0.3 * v[0]).toFixed(3)})`;
  }
  function extraCss(st, k) {
    return (st.a === 12 || st.b === 12) ? visionCss(k) : st.a === 13 ? thickCss(k) : '';
  }

  const perfOf = () => PERF[settings.perf] || PERF.medium;
  const paceOf = () => PACE[settings.pace] || 1;
  const speedFactor = () => (0.1 + (settings.speed / 100) * 2.4) * paceOf();
  const glowGain = () => Math.min(1, 2.5 / speedFactor());
  const intensity = () => Math.max(0, Math.min(1, settings.intensity / 100));

  let clock = 0, lclock = 0, lastNow = performance.now();
  function tick() {
    const now = performance.now(), dt = Math.min(0.1, (now - lastNow) / 1000), sf = speedFactor();
    clock += dt * sf;
    lclock += dt * Math.min(sf, LIGHT_CAP);
    lastNow = now;
    return clock;
  }

  // Cycle uses the capped light clock so stages and cross-fades stay slow even on Turbo.
  function cycleState() {
    const STAGE = 7.0, n = CYCLE.length;
    const pos = lclock / STAGE;
    const i = Math.floor(pos) % n;
    const f = pos - Math.floor(pos);
    const blend = f < 0.6 ? 0 : (f - 0.6) / 0.4;
    return { a: CYCLE[i], b: CYCLE[(i + 1) % n], mix: blend * blend * (3 - 2 * blend) };
  }

  let brainStart = performance.now(), brainPhase = 0, brainSpin = 0, brainLast = performance.now();
  const FADE = 2.0, VIEW = 8.0;
  function brainState() {
    const now = performance.now();
    const dt = Math.min(0.1, (now - brainLast) / 1000); brainLast = now;
    const spin = 0.05 * paceOf();
    const rate = Math.min(0.25 + 0.6 * (settings.speed / 100), BRAIN_MAX_HZ - 4.8 * spin / (2 * Math.PI));
    brainHz = rate + 4.8 * spin / (2 * Math.PI);
    brainPhase = (brainPhase + dt * rate) % 1;
    brainSpin = (brainSpin + dt * spin) % (10 * Math.PI);
    const adapt = Math.max(5, Math.min(120, Number(settings.adapt) || 25));
    const sA = adapt + FADE + VIEW;
    const sD = 4 + 10 + 4 + 4;
    const total = sA * 2 + sD;
    let x = ((now - brainStart) / 1000) % total;
    const ease = (u) => u * u * (3 - 2 * u);
    const block = (type, t) => {
      let alpha;
      if (t < 1.5) alpha = ease(t / 1.5);
      else if (t < adapt) alpha = 1;
      else if (t < adapt + FADE) alpha = 1 - ease((t - adapt) / FADE);
      else alpha = 0;
      return { type, alpha };
    };
    if (x < sA) return block(0, x);
    x -= sA;
    if (x < sA) return block(1, x);
    x -= sA;
    const alpha = x < 4 ? ease(x / 4) : x < 14 ? 1 : x < 18 ? 1 - ease((x - 14) / 4) : 0;
    return { type: 2, alpha };
  }

  function modeState() {
    const m = MODES[settings.mode] ?? 4;
    if (m === 4) return cycleState();
    if (m === 5) return { a: 0, b: 0, mix: 0, brain: true };
    return { a: m, b: m, mix: 0 };
  }

  let svgRoot = null;
  const filteredVideos = new Set();
  function ensureSvg() {
    if (svgRoot && svgRoot.isConnected) return svgRoot;
    const NS = 'http://www.w3.org/2000/svg';
    svgRoot = document.createElementNS(NS, 'svg');
    svgRoot.setAttribute('width', '0');
    svgRoot.setAttribute('height', '0');
    svgRoot.setAttribute('aria-hidden', 'true');
    svgRoot.style.cssText = 'position:absolute!important;width:0!important;height:0!important;overflow:hidden!important;pointer-events:none!important;';
    svgRoot.innerHTML = `
      <defs>
        <filter id="${FILTER_ID}" x="-5%" y="-5%" width="110%" height="110%" color-interpolation-filters="sRGB">
          <feTurbulence id="${TURB_ID}" type="fractalNoise" baseFrequency="0.008 0.012" numOctaves="2" seed="3" result="noise"/>
          <feDisplacementMap id="${DISP_ID}" in="SourceGraphic" in2="noise" scale="20" xChannelSelector="R" yChannelSelector="G" result="displaced"/>
          <feColorMatrix id="${HUE_ID}" in="displaced" type="hueRotate" values="0"/>
        </filter>
      </defs>`;
    (document.body || document.documentElement).appendChild(svgRoot);
    return svgRoot;
  }

  let fallbackLastUpdate = 0;
  function updateFallbackFilter(t, force) {
    const now = performance.now();
    const interval = IS_LITE ? Math.max(50, 1000 / (perfOf().fps || 24)) : 50;
    if (!force && now - fallbackLastUpdate < interval) return;
    fallbackLastUpdate = now;
    ensureSvg();
    const k = intensity();
    const st = modeState();
    const turb = document.getElementById(TURB_ID);
    const disp = document.getElementById(DISP_ID);
    const hue = document.getElementById(HUE_ID);
    if (!turb || !disp || !hue) return;
    const P = [
      { fx: 0.006, fy: 0.014, scale: 45, hue: 0 },
      { fx: 0.05, fy: 0.05, scale: 30, hue: 20 },
      { fx: 0.012, fy: 0.012, scale: 28, hue: 0 },
      { fx: 0.004, fy: 0.004, scale: 10, hue: 160 },
      null, null,
      { fx: 0.02, fy: 0.02, scale: 16, hue: 0 },
      { fx: 0.01, fy: 0.01, scale: 22, hue: 40 },
      { fx: 0.003, fy: 0.012, scale: 40, hue: 0 },
      { fx: 0.002, fy: 0.03, scale: 26, hue: -15 },
      { fx: 0.03, fy: 0.03, scale: 20, hue: 12 },
      { fx: 0.005, fy: 0.005, scale: 25, hue: 0 },
      { fx: 0.004, fy: 0.004, scale: 0, hue: 0 },
      { fx: 0.004, fy: 0.004, scale: 0, hue: 0 }
    ];
    const A = P[st.a], B = P[st.b], m = st.mix;
    if (!A || !B) return;
    const L = (x, y) => x + (y - x) * m;
    const wob = 1 + 0.35 * Math.sin(t * 0.7);
    const fx = L(A.fx, B.fx) * wob, fy = L(A.fy, B.fy) * (2 - wob);
    let scale = L(A.scale, B.scale) * k;
    if (st.a === 1 || st.b === 1) scale *= 0.5 + 0.5 * Math.abs(Math.sin(lclock * 0.6));
    if (st.a === 11 || st.b === 11) scale *= 0.55 + 0.45 * Math.sin(lclock * 0.9);
    turb.setAttribute('baseFrequency', `${fx.toFixed(5)} ${fy.toFixed(5)}`);
    disp.setAttribute('scale', scale.toFixed(2));
    hue.setAttribute('values', (L(A.hue, B.hue) * k * Math.sin(t * 0.3)).toFixed(1));
    const extra = extraCss(st, k);
    for (const v of filteredVideos) v.style.setProperty('filter', `url(#${FILTER_ID})` + extra, 'important');
  }

  const UNIFORMS = [
    'u_tex', 'u_time', 'u_int', 'u_res', 'u_crop', 'u_modeA', 'u_modeB', 'u_mix',
    'u_brain', 'u_bType', 'u_bAlpha', 'u_bPhase', 'u_bSpin', 'u_lt', 'u_gl', 'u_vis', 'u_vh', 'u_th'
  ];

  function compileProgram(gl) {
    const sh = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
        console.warn('[Zig Metamorphosis v3] shader error', gl.getShaderInfoLog(s));
        return null;
      }
      return s;
    };
    const vs = sh(gl.VERTEX_SHADER, VERT), fs = sh(gl.FRAGMENT_SHADER, FRAG);
    if (!vs || !fs) return null;
    const p = gl.createProgram();
    gl.attachShader(p, vs); gl.attachShader(p, fs); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      console.warn('[Zig Metamorphosis v3] link error', gl.getProgramInfoLog(p));
      return null;
    }
    return p;
  }

  function contentBox(video) {
    const v = video;
    const r = v.getBoundingClientRect();
    const cs = getComputedStyle(v);
    const vw = v.videoWidth || r.width, vh = v.videoHeight || r.height;
    const fit = cs.objectFit || 'contain';
    let box = {
      left: r.left + v.clientLeft, top: r.top + v.clientTop,
      width: v.clientWidth || r.width, height: v.clientHeight || r.height
    };
    let crop = [1, 1, 0, 0];
    if (vw && vh && box.width && box.height) {
      const ea = box.width / box.height, va = vw / vh;
      if (fit === 'contain' || fit === 'scale-down') {
        if (va > ea) { const h = box.width / va; box.top += (box.height - h) / 2; box.height = h; }
        else { const w = box.height * va; box.left += (box.width - w) / 2; box.width = w; }
      } else if (fit === 'cover') {
        if (va > ea) { const s = ea / va; crop = [s, 1, (1 - s) / 2, 0]; }
        else { const s = va / ea; crop = [1, s, 0, (1 - s) / 2]; }
      }
    }
    const visible = r.width > 1 && r.height > 1 && cs.visibility !== 'hidden' && cs.display !== 'none';
    return { box, crop, visible };
  }

  function placeCanvas(canvas, box, scaleExtra) {
    const c = canvas;
    const op = c.offsetParent;
    let ox, oy;
    if (op && op !== document.body && op !== document.documentElement) {
      const pr = op.getBoundingClientRect();
      ox = pr.left + op.clientLeft - op.scrollLeft;
      oy = pr.top + op.clientTop - op.scrollTop;
    } else if (op === document.body && getComputedStyle(document.body).position !== 'static') {
      const pr = document.body.getBoundingClientRect();
      ox = pr.left; oy = pr.top;
    } else { ox = -window.scrollX; oy = -window.scrollY; }
    const left = box.left - ox, top = box.top - oy;
    const s = c.style;
    const L = left.toFixed(2) + 'px', T = top.toFixed(2) + 'px';
    const W = box.width.toFixed(2) + 'px', H = box.height.toFixed(2) + 'px';
    if (s.left !== L) s.left = L;
    if (s.top !== T) s.top = T;
    if (s.width !== W) s.width = W;
    if (s.height !== H) s.height = H;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let bw = Math.max(1, Math.round(box.width * dpr));
    let bh = Math.max(1, Math.round(box.height * dpr));
    let scale = scaleExtra || 1;
    if (IS_LITE) scale *= (perfOf().scale || 1) * (settings.mode === 'brain' ? BRAIN_SCALE : 1);
    bw = Math.round(bw * scale); bh = Math.round(bh * scale);
    const cap = Math.min(1, MAX_BUFFER / Math.max(bw, bh, 1));
    bw = Math.max(1, Math.round(bw * cap));
    bh = Math.max(1, Math.round(bh * cap));
    if (c.width !== bw || c.height !== bh) { c.width = bw; c.height = bh; }
  }

  class VideoMorph {
    constructor(video) {
      this.video = video;
      this.mode = 'none';
      this.canvas = null; this.gl = null; this.prog = null; this.tex = null; this.u = {};
      this.savedOpacity = null; this.savedOpacityPriority = '';
      this.savedFilter = null; this.savedFilterPriority = '';
      this.hidden = false; this.filtered = false;
      this.hasFrame = false; this.texBlocked = false;
      this.running = false; this.onScreen = true; this.layoutDirty = true;
      this.rvfcId = 0; this.rafId = 0; this.layoutRaf = 0;
      this.lastDraw = 0; this.lastTime = -1; this.lastPlace = 0; this.lastLayout = null;
      if (IS_LITE && typeof IntersectionObserver !== 'undefined') {
        this.io = new IntersectionObserver((ents) => {
          for (const en of ents) this.onScreen = en.isIntersecting;
          this.updateLite();
        }, { threshold: 0 });
        this.io.observe(video);
      }
      if (IS_LITE && typeof ResizeObserver !== 'undefined') {
        this.ro = new ResizeObserver(() => this.markLayout());
        this.ro.observe(video);
      }
    }

    markLayout() {
      this.layoutDirty = true;
      if (!this.layoutRaf) {
        this.layoutRaf = requestAnimationFrame(() => {
          this.layoutRaf = 0;
          if (IS_LITE && !this.running && this.mode === 'gl') this.draw(true);
        });
      }
    }

    start() {
      if (this.mode === 'none' && !this.initGL()) this.startFallback();
      if (IS_LITE) this.updateLite();
    }

    shouldRunLite() {
      const v = this.video;
      return settings.enabled && !document.hidden && this.onScreen && !v.paused && !v.ended && v.readyState >= 2;
    }

    updateLite() {
      if (!IS_LITE) return;
      if (this.mode === 'fallback') {
        if (settings.enabled && !modeState().brain) this.cssFilter(true);
        else this.cssFilter(false);
        updateFallbackFilter(clock, true);
      }
      const want = this.shouldRunLite();
      if (want && !this.running) { this.running = true; lastNow = performance.now(); this.scheduleLite(); }
      else if (!want && this.running) { this.running = false; this.cancelLite(); }
    }

    scheduleLite() {
      if (!this.running) return;
      const v = this.video;
      if (typeof v.requestVideoFrameCallback === 'function') {
        this.rvfcId = v.requestVideoFrameCallback(() => { this.rvfcId = 0; this.onFrameLite(true); });
      } else {
        this.rafId = requestAnimationFrame(() => { this.rafId = 0; this.onFrameLite(false); });
      }
    }

    cancelLite() {
      const v = this.video;
      if (this.rvfcId && v.cancelVideoFrameCallback) v.cancelVideoFrameCallback(this.rvfcId);
      if (this.rafId) cancelAnimationFrame(this.rafId);
      this.rvfcId = 0; this.rafId = 0;
    }

    onFrameLite(isNewFrame) {
      if (!this.running) return;
      const now = performance.now();
      const brain = settings.mode === 'brain';
      const fps = brain ? Math.min(BRAIN_FPS, perfOf().fps) : perfOf().fps;
      const v = this.video;
      const fresh = isNewFrame || v.currentTime !== this.lastTime;
      if (fresh && now - this.lastDraw >= 1000 / fps - 2) {
        this.lastDraw = now; this.lastTime = v.currentTime;
        const t = tick();
        if (this.mode === 'gl') this.draw(false, t);
        else if (this.mode === 'fallback') updateFallbackFilter(t, false);
      }
      this.scheduleLite();
    }

    initGL() {
      const v = this.video, parent = v.parentNode;
      if (!parent) return false;
      const c = document.createElement('canvas');
      c.className = CANVAS_CLASS;
      c.setAttribute('aria-hidden', 'true');
      c.style.cssText = 'position:absolute!important;pointer-events:none!important;margin:0!important;padding:0!important;' +
        'border:0!important;transform:none!important;display:none;left:0;top:0;width:0;height:0;';
      const z = getComputedStyle(v).zIndex;
      if (z && z !== 'auto') c.style.zIndex = z;
      const gl = c.getContext('webgl', {
        alpha: true, premultipliedAlpha: true, antialias: false,
        depth: false, stencil: false, preserveDrawingBuffer: false,
        powerPreference: IS_LITE ? 'low-power' : 'default'
      }) || c.getContext('experimental-webgl');
      if (!gl) return false;
      const prog = compileProgram(gl);
      if (!prog) return false;
      parent.insertBefore(c, v.nextSibling);
      this.canvas = c; this.gl = gl; this.prog = prog;
      gl.useProgram(prog);
      const buf = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(prog, 'a_pos');
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      this.tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, this.tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      this.u = {};
      for (const n of UNIFORMS) this.u[n] = gl.getUniformLocation(prog, n);
      gl.uniform1i(this.u.u_tex, 0);
      c.addEventListener('webglcontextlost', (e) => {
        if (this.canvas !== c) return;
        e.preventDefault();
        this.teardownGL();
        this.startFallback();
        if (IS_LITE) this.updateLite();
      });
      this.mode = 'gl';
      this.hasFrame = false; this.texBlocked = false;
      this.savedOpacity = v.style.getPropertyValue('opacity');
      this.savedOpacityPriority = v.style.getPropertyPriority('opacity');
      return true;
    }

    hideVideo(on) {
      const v = this.video;
      if (on && !this.hidden) { v.style.setProperty('opacity', '0', 'important'); this.hidden = true; }
      if (!on && this.hidden) {
        if (this.savedOpacity) v.style.setProperty('opacity', this.savedOpacity, this.savedOpacityPriority || '');
        else v.style.removeProperty('opacity');
        this.hidden = false;
      }
    }

    cssFilter(on) {
      const v = this.video;
      if (on && !this.filtered) {
        ensureSvg();
        this.savedFilter = v.style.getPropertyValue('filter');
        this.savedFilterPriority = v.style.getPropertyPriority('filter');
        v.style.setProperty('filter', `url(#${FILTER_ID})`, 'important');
        this.filtered = true; filteredVideos.add(v);
      }
      if (!on && this.filtered) {
        if (this.savedFilter) v.style.setProperty('filter', this.savedFilter, this.savedFilterPriority || '');
        else v.style.removeProperty('filter');
        this.filtered = false; filteredVideos.delete(v);
      }
    }

    draw(redrawOnly, t) {
      if (t == null) t = clock;
      const v = this.video;
      const st = modeState();
      if (this.mode === 'fallback') {
        if (st.brain) this.cssFilter(false);
        else { this.cssFilter(true); updateFallbackFilter(t, !!redrawOnly); }
        return;
      }
      if (this.mode !== 'gl' || !v.isConnected || !this.canvas) return;
      if (this.canvas.parentNode !== v.parentNode || this.canvas.previousSibling !== v) {
        if (v.parentNode) v.parentNode.insertBefore(this.canvas, v.nextSibling);
      }
      const now = contentBox(v);
      if (!layout.visible) { this.canvas.style.display = 'none'; return; }
      placeCanvas(this.canvas, layout.box);
      const gl = this.gl;
      gl.viewport(0, 0, this.canvas.width, this.canvas.height);
      gl.uniform2f(this.u.u_res, this.canvas.width, this.canvas.height);
      gl.uniform1f(this.u.u_int, intensity());

      if (st.brain) {
        this.hideVideo(false); this.cssFilter(false);
        if (this.canvas.style.display === 'none') this.canvas.style.display = 'block';
        const b = brainState();
        gl.uniform1f(this.u.u_brain, 1);
        gl.uniform1f(this.u.u_bType, b.type);
        gl.uniform1f(this.u.u_bAlpha, b.alpha);
        gl.uniform1f(this.u.u_bPhase, brainPhase);
        gl.uniform1f(this.u.u_bSpin, brainSpin);
        gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
        gl.drawArrays(gl.TRIANGLES, 0, 6);
        stats.draws++;
        return;
      }
      gl.uniform1f(this.u.u_brain, 0);

      if (this.texBlocked) {
        this.canvas.style.display = 'none';
        this.cssFilter(true); updateFallbackFilter(t, !!redrawOnly);
        return;
      }
      this.cssFilter(false);
      if (!redrawOnly && v.readyState >= 2 && v.videoWidth > 0) {
        try {
          gl.bindTexture(gl.TEXTURE_2D, this.tex);
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, v);
          this.hasFrame = true;
          stats.uploads++;
        } catch (e) {
          console.info('[Zig Metamorphosis v3] WebGL blocked for this video (' + (e && e.name) + '); using filter fallback.');
          this.texBlocked = true; this.hasFrame = false;
          this.hideVideo(false);
          return;
        }
      }
      if (!this.hasFrame) { this.canvas.style.display = 'none'; return; }
      if (this.canvas.style.display === 'none') this.canvas.style.display = 'block';
      this.hideVideo(true);
      gl.uniform1f(this.u.u_time, t);
      gl.uniform1f(this.u.u_lt, lclock);
      gl.uniform1f(this.u.u_gl, glowGain());
      const vs = visionState();
      gl.uniform4f(this.u.u_vis, vs[0], vs[1], vs[2], vs[3]);
      gl.uniform1f(this.u.u_vh, vs[4]);
      gl.uniform1f(this.u.u_th, thickAmt(st));
      gl.uniform4f(this.u.u_crop, layout.crop[0], layout.crop[1], layout.crop[2], layout.crop[3]);
      gl.uniform1f(this.u.u_modeA, st.a);
      gl.uniform1f(this.u.u_modeB, st.b);
      gl.uniform1f(this.u.u_mix, st.mix);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      stats.draws++;
    }

    get usingFallback() {
      return this.mode === 'fallback' || (this.mode === 'gl' && this.texBlocked && settings.mode !== 'brain');
    }

    startFallback() {
      if (this.mode === 'fallback') return;
      this.mode = 'fallback';
    }

    teardownGL() {
      const old = this.canvas;
      this.canvas = null;
      if (old) {
        try { const ext = this.gl && this.gl.getExtension('WEBGL_lose_context'); ext && ext.loseContext(); } catch (e) {}
        old.remove();
      }
      this.gl = null;
      this.hideVideo(false);
      this.mode = 'none';
    }

    stop() {
      if (IS_LITE) { this.running = false; this.cancelLite(); }
      if (this.mode === 'gl') this.teardownGL();
      this.hideVideo(false);
      this.cssFilter(false);
      this.mode = 'none';
    }

    destroy() {
      this.stop();
      if (this.io) try { this.io.disconnect(); } catch (e) {}
      if (this.ro) try { this.ro.disconnect(); } catch (e) {}
    }
  }

  // -------- full: every eligible video. lite: one best target.
  const controllers = new Map();
  let active = null;
  let rafId = 0;
  let scanTimer = 0;

  function eligible(v) {
    const r = v.getBoundingClientRect();
    return v.isConnected && r.width >= MIN_W && r.height >= MIN_H;
  }

  function pickTarget() {
    let best = null, bestScore = 0;
    const vh = window.innerHeight, vw = window.innerWidth;
    for (const v of document.querySelectorAll('video')) {
      if (!v.isConnected) continue;
      const r = v.getBoundingClientRect();
      if (r.width < MIN_W || r.height < MIN_H) continue;
      const visW = Math.max(0, Math.min(r.right, vw) - Math.max(r.left, 0));
      const visH = Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0));
      let score = visW * visH;
      if (!score) continue;
      if (!v.paused && !v.ended) score *= 4;
      if (score > bestScore) { bestScore = score; best = v; }
    }
    return best;
  }

  function scan() {
    if (IS_LITE) {
      if (!settings.enabled) return;
      const target = pickTarget();
      if (active && active.video.isConnected && target && target !== active.video) {
        const cur = active.video, cr = cur.getBoundingClientRect(), tr = target.getBoundingClientRect();
        const curPlaying = !cur.paused && !cur.ended, tgtPlaying = !target.paused && !target.ended;
        if (curPlaying === tgtPlaying && cr.width * cr.height >= tr.width * tr.height * 0.8) return;
      }
      if (active && (!target || target !== active.video || !active.video.isConnected)) {
        active.destroy(); active = null;
      }
      if (!active && target) { active = new VideoMorph(target); active.start(); }
      return;
    }
    const vids = document.querySelectorAll('video');
    for (const v of vids) {
      if (!controllers.has(v) && eligible(v)) controllers.set(v, new VideoMorph(v));
    }
    for (const [v, c] of controllers) {
      if (!v.isConnected) { c.stop(); controllers.delete(v); }
    }
    if (settings.enabled) for (const c of controllers.values()) c.start();
  }

  function loopFull() {
    rafId = 0;
    if (!settings.enabled) return;
    const t = tick();
    for (const c of controllers.values()) {
      try { c.draw(false, t); } catch (e) { console.warn('[Zig Metamorphosis v3]', e); }
    }
    rafId = requestAnimationFrame(loopFull);
  }

  function scheduleScan(delay) {
    if (!scanTimer) scanTimer = setTimeout(() => { scanTimer = 0; scan(); }, delay || (IS_LITE ? 600 : 300));
  }

  function apply(next) {
    const wasOn = settings.enabled, wasMode = settings.mode, wasPerf = settings.perf;
    settings = { ...DEFAULTS, ...next };
    if (settings.mode === 'brain' && (wasMode !== 'brain' || !wasOn)) brainStart = performance.now();
    if (settings.enabled) {
      scan();
      lastNow = performance.now();
      if (IS_LITE) {
        if (active) {
          if (wasPerf !== settings.perf || wasMode !== settings.mode) active.layoutDirty = true;
          active.updateLite();
          if (!active.running && active.mode === 'gl' && active.hasFrame) active.draw(true);
        }
      } else if (!rafId) {
        rafId = requestAnimationFrame(loopFull);
      }
    } else if (wasOn) {
      if (!IS_LITE && rafId) { cancelAnimationFrame(rafId); rafId = 0; }
      if (IS_LITE && active) { active.destroy(); active = null; }
      else for (const c of controllers.values()) c.stop();
      if (svgRoot) { svgRoot.remove(); svgRoot = null; }
    }
  }

  try {
    api.storage.local.get(STORAGE_KEY).then((d) => apply((d && d[STORAGE_KEY]) || {}), () => apply({}));
    api.storage.onChanged.addListener((ch, area) => {
      if (area === 'local' && ch[STORAGE_KEY]) apply(ch[STORAGE_KEY].newValue || {});
    });
    api.runtime.onMessage.addListener((msg, _sender, reply) => {
      if (!msg) return;
      if (msg.type === MSG_SET) { apply(msg.settings || {}); reply({ ok: true }); }
      else if (msg.type === MSG_STATUS) {
        if (IS_LITE) {
          const n = document.querySelectorAll('video').length;
          if (n || window === window.top) {
            reply({
              videos: n,
              gl: active && active.mode === 'gl' && !active.usingFallback ? 1 : 0,
              fallback: active && active.usingFallback ? 1 : 0
            });
          }
        } else {
          scan();
          let fallback = 0, gl = 0;
          for (const c of controllers.values()) { if (c.usingFallback) fallback++; else if (c.mode === 'gl') gl++; }
          if (controllers.size || window === window.top) reply({ videos: controllers.size, gl, fallback });
        }
      }
    });
  } catch (e) { /* extension context may be invalidated */ }

  new MutationObserver(() => { if (settings.enabled) scheduleScan(IS_LITE ? 700 : 300); })
    .observe(document.documentElement, { childList: true, subtree: true });
  if (IS_LITE) {
    document.addEventListener('play', () => { if (settings.enabled) scheduleScan(100); }, true);
    document.addEventListener('visibilitychange', () => { if (active) active.updateLite(); });
    let resizeRaf = 0;
    const relayout = () => {
      if (!resizeRaf) resizeRaf = requestAnimationFrame(() => {
        resizeRaf = 0;
        if (active) active.markLayout();
        scheduleScan(600);
      });
    };
    window.addEventListener('resize', relayout, { passive: true });
    document.addEventListener('fullscreenchange', relayout);
    window.addEventListener('scroll', () => { if (settings.enabled) scheduleScan(800); }, { passive: true });
  } else {
    setInterval(() => { if (settings.enabled) scan(); }, 2000);
    document.addEventListener('fullscreenchange', () => { if (settings.enabled) scan(); });
  }

  document.documentElement.addEventListener(QUERY_EVT, () => {
    const payload = IS_LITE ? {
      owner: ZIG_OWNER, version: '3.0.0', profile: PROFILE,
      enabled: settings.enabled,
      modes: active ? [active.usingFallback ? 'fallback' : active.mode] : [],
      running: !!(active && active.running), draws: stats.draws, uploads: stats.uploads,
      buffer: active && active.canvas ? [active.canvas.width, active.canvas.height] : null,
      target: active ? active.video.id || null : null,
      pace: settings.pace, speedFactor: speedFactor(),
      lightRate: Math.min(speedFactor(), LIGHT_CAP), brainHz
    } : {
      owner: ZIG_OWNER, version: '3.0.0', profile: PROFILE,
      enabled: settings.enabled,
      modes: [...controllers.values()].map((c) => c.usingFallback ? 'fallback' : c.mode),
      mode: settings.mode, pace: settings.pace,
      speedFactor: speedFactor(), lightRate: Math.min(speedFactor(), LIGHT_CAP), brainHz
    };
    document.documentElement.setAttribute(DATA_ATTR, JSON.stringify(payload));
  });
})();
