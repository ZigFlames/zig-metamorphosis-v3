ZIG METAMORPHOSIS v3.0.0 - Chrome (and Brave) extension
Live, organic morph effects over any video playing in Chrome (YouTube, Vimeo, etc.)

PHOTOSENSITIVITY NOTE: No mode flashes or strobes (all changes are slower than about once per second), including Zig Vision's colour primer and edge drift, but the swirl and illusion effects can still cause discomfort; stop if you feel dizzy or unwell.

INSTALL (on a Mac or PC - Chrome on phones does not support extensions)
1. Unzip full-chrome.zip if you have the zip (double-click it). You get a folder named "full-chrome".
2. In Chrome's address bar, type  chrome://extensions  and press Enter.
3. Turn on "Developer mode" (switch in the top-right corner).
4. Click "Load unpacked" and choose the "full-chrome" folder.
5. Click the puzzle-piece icon in the toolbar and pin "Zig Metamorphosis".
6. Reload any tab that was already open.

If you already have the old v2 add-on, turn that one off or remove it first so you don't run both at once.

USE
Click the Zig Metamorphosis icon in the toolbar. All controls are in this popup.

- On/off switch: starts or stops the effect.
- Mode:
    Metamorphosis Cycle - flows by itself through all 10 morphs
    Liquid Melt, Dissolve & Reform, Refraction, Chroma Morph
    Ripple Pool, Kaleido Bloom, Smoke Drift, Mirror Twin
    Glass Shatter Flow, Pulse Breathe
    Zig Vision (perception boost) and Thick (warm glow + a slow widening)
    Brain Morph - watch the red centre dot while a slow swirl plays.
- Intensity and Fine-tune speed sliders.
- Speed buttons: Slow (0.5x), Normal (1x), Fast (2x), Turbo (3.5x).
Safety: brightness and contrast changes run on a separately capped clock, so nothing pulses faster than about 0.4 Hz even on Turbo. Brain Morph stays under 0.9 Hz.

Your settings are remembered and apply to all tabs.

LIMITATIONS
- Protected (DRM) video such as Netflix, Disney+, Prime Video and some paid streams cannot be fully effected.
- Some sites block full effects; the add-on then uses a simpler warp/colour filter. Brain Morph still works fully.
- When a video uses the browser's own built-in fullscreen, effects may not show. YouTube's fullscreen button works.

OWNERSHIP
---------
Zig Metamorphosis v3.0.0 (c) 2026 ZigFlames (zigflames.com). All rights reserved.
License ZIGMETA3-A41F-9C27-E6B8  -  signature ZS-B7E2C91F04A65D38 (embedded in every build).
Copying, redistributing or reselling this add-on, or removing this notice, is not permitted.

